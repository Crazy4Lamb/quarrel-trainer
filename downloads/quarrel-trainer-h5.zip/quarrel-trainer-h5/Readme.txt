Boundary Lab / 吵架练习器 — Installable H5

Upload the contents of quarrel-trainer-h5 to an HTTPS static website, keeping the directory structure. Open that URL on a phone and choose Install to home screen.
首次联网打开并缓存后可离线练习。AI 模式仍需联网。安装需要 HTTPS，不能从 file:// 或普通手机局域网 HTTP 地址安装。
Android: browser menu → Install app / Add to home screen.
iPhone: Safari → Share → Add to Home Screen.
Version: 6e3092d3131f8b98
